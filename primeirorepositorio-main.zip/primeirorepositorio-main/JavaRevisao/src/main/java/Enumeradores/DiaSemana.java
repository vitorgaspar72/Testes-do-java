package Enumeradores;

public enum DiaSemana {
   SEGUNDA,TERCA,QUARTA,QUINTA,SEXTA,SABADO,DOMINGO;
	
	
}
