package TiposdeClasse;

public interface InterfaceAnonima {
	public void testeHeranca();
}
